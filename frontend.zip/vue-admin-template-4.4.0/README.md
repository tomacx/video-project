使用vue element 框架
平台:VSCode 
分别执行以下两条命令
npm install
npm run dev
